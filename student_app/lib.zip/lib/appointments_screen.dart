import 'package:flutter/material.dart';
import 'bottom_nav_bar.dart';
import 'request_appointment_screen.dart';
import 'home_screen.dart';
import 'journals_screen.dart';
import 'resources_screen.dart';
import 'support_screen.dart';

class AppointmentsScreen extends StatelessWidget {
  const AppointmentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Appointments',
          style: TextStyle(
            color: Color(0xFF1F2937),
            fontWeight: FontWeight.w600,
            fontSize: 28,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Upcoming Appointment
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Upcoming Appointment', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w600, fontSize: 18, color: Color(0xFF1F2937))),
                          SizedBox(height: 8),
                          Text('Mon, Nov 3 · 10:00 AM', style: TextStyle(fontFamily: 'Poppins', fontSize: 16, color: Color(0xFF1F2937))),
                          Text('Dr. Jane Smith', style: TextStyle(fontFamily: 'Poppins', fontSize: 16, color: Color(0xFF5CB8A2))),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Color(0xFF5CB8A2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text('Confirmed', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontFamily: 'Nunito Sans')),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Request Appointment Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const RequestAppointmentScreen()),
                  );
                },
                child: const Text('Request Appointment', style: TextStyle(color: Colors.white, fontFamily: 'Poppins', fontWeight: FontWeight.w600, fontSize: 16)),
              ),
            ),
            const SizedBox(height: 28),
            const Text('Past Appointments', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w600, fontSize: 18, color: Color(0xFF1F2937))),
            const SizedBox(height: 12),
            // Past Appointments List
            Expanded(
              child: ListView(
                children: [
                  _pastAppointmentCard('Oct 20, 2025', 'Dr. Jane Smith', 'Consultation'),
                  _pastAppointmentCard('Sep 15, 2025', 'Dr. John Doe', 'Follow-up'),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: 2,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const HomeScreen()));
              break;
            case 1:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const JournalsScreen()));
              break;
            case 2:
              // Already on AppointmentsScreen
              break;
            case 3:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const ResourcesScreen()));
              break;
            case 4:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const SupportScreen()));
              break;
          }
        },
      ),
    );
  }

  Widget _pastAppointmentCard(String date, String doctor, String type) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(date, style: const TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w600, color: Color(0xFF1F2937))),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(doctor, style: const TextStyle(fontFamily: 'Poppins', color: Color(0xFF5CB8A2))),
            Text(type, style: const TextStyle(fontFamily: 'Poppins', color: Color(0xFF6B7280))),
          ],
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: Color(0xFF6B7280),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Text('Completed', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
        ),
      ),
    );
  }
}
