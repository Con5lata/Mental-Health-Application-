import 'package:flutter/material.dart';
import 'bottom_nav_bar.dart';
import 'home_screen.dart';
import 'journals_screen.dart';
import 'appointments_screen.dart';
import 'support_screen.dart';

class ResourcesScreen extends StatelessWidget {
  const ResourcesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Resources',
          style: TextStyle(
            color: Color(0xFF1F2937),
            fontWeight: FontWeight.w600,
            fontSize: 28,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _searchBar(),
            const SizedBox(height: 16),
            _categoryFilters(),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  _resourceCard('Managing Stress', 'Tips and strategies to manage stress effectively.', true),
                  _resourceCard('Exam Preparation', 'How to prepare for exams without burnout.', false),
                  _resourceCard('Burnout Recovery', 'Recognize and recover from academic burnout.', true),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: 3,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const HomeScreen()));
              break;
            case 1:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const JournalsScreen()));
              break;
            case 2:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const AppointmentsScreen()));
              break;
            case 3:
              // Already on ResourcesScreen
              break;
            case 4:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => const SupportScreen()));
              break;
          }
        },
      ),
    );
  }

  Widget _searchBar() {
    return TextField(
      decoration: InputDecoration(
        hintText: 'Search resources...',
        prefixIcon: const Icon(Icons.search, color: Color(0xFF6B7280)),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
      ),
      style: const TextStyle(fontFamily: 'Nunito Sans', color: Color(0xFF1F2937)),
    );
  }

  Widget _categoryFilters() {
    final categories = ['All', 'Stress', 'Exams', 'Burnout'];
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: categories.map((cat) {
        return Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: ChoiceChip(
            label: Text(cat, style: const TextStyle(fontFamily: 'Nunito Sans', color: Color(0xFF1F2937))),
            selected: cat == 'All',
            selectedColor: const Color(0xFF5CB8A2),
            backgroundColor: const Color(0xFFE5E7EB),
            onSelected: (_) {},
          ),
        );
      }).toList(),
    );
  }

  Widget _resourceCard(String title, String desc, bool isSaved) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w600, fontSize: 18, color: Color(0xFF1F2937))),
                  const SizedBox(height: 6),
                  Text(desc, style: const TextStyle(fontFamily: 'Nunito Sans', fontSize: 15, color: Color(0xFF6B7280))),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () {},
                    child: const Text('Read more', style: TextStyle(color: Color(0xFF0F766E), fontFamily: 'Nunito Sans', fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.star,
              color: isSaved ? Color(0xFFEAB308) : Color(0xFF6B7280),
              size: 28,
            ),
          ],
        ),
      ),
    );
  }
}
