import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // For date formatting
import 'appointments_screen.dart';
import 'bottom_nav_bar.dart';
import 'journals_screen.dart';
import 'resources_screen.dart';
import 'support_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String? _userName;
  DocumentSnapshot? _nextAppointment;

  @override
  void initState() {
    super.initState();
    _fetchUserData();
    _fetchNextAppointment();
  }

  Future<void> _fetchUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      if (mounted) {
        setState(() {
          _userName = userDoc.data()?['name'];
        });
      }
    }
  }

  Future<void> _fetchNextAppointment() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('appointments')
          .where('user_id', isEqualTo: user.uid)
          .where('date', isGreaterThanOrEqualTo: Timestamp.now())
          .orderBy('date')
          .limit(1)
          .get();

      if (mounted && querySnapshot.docs.isNotEmpty) {
        setState(() {
          _nextAppointment = querySnapshot.docs.first;
        });
      }
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    switch (index) {
      case 0:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const JournalsScreen()),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const AppointmentsScreen()),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const ResourcesScreen()),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const SupportScreen()),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Personalized Greeting
              Text(
                'Welcome back,',
                style: TextStyle(fontSize: 22, color: Colors.grey[600]),
              ),
              Text(
                _userName ?? 'User',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFB39DDB),
                ),
              ),
              const SizedBox(height: 24),

              // Mood Check-in Display
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text('😞', style: TextStyle(fontSize: 32)),
                  Text('😐', style: TextStyle(fontSize: 32)),
                  Text('🙂', style: TextStyle(fontSize: 32)),
                  Text('😊', style: TextStyle(fontSize: 32)),
                  Text('😁', style: TextStyle(fontSize: 32)),
                ],
              ),
              const SizedBox(height: 32),

              // Navigation Grid
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                children: [
                  _buildGridItem(Icons.book_outlined, 'Journals'),
                  _buildGridItem(Icons.calendar_today_outlined, 'Appointments'),
                  _buildGridItem(Icons.lightbulb_outline, 'Resources'),
                  _buildGridItem(Icons.support_agent_outlined, 'Support'),
                ],
              ),
              const SizedBox(height: 24),

              // Next Appointment Card
              const Text(
                'Next Appointment',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black54),
              ),
              const SizedBox(height: 8),
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 2,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20.0),
                  child: _nextAppointment != null
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _formatAppointmentDate((_nextAppointment!['date'] as Timestamp).toDate()),
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF4DB6AC)),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'with ${_nextAppointment!['counsellor_name'] ?? 'your counsellor'}',
                              style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                            ),
                          ],
                        )
                      : const Text(
                          'No upcoming appointments yet.',
                          style: TextStyle(fontSize: 16, color: Colors.grey),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavBar(currentIndex: _selectedIndex, onTap: _onItemTapped),
    );
  }

  Widget _buildGridItem(IconData icon, String label) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: InkWell(
        onTap: () {
          if (label == 'Appointments') {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AppointmentsScreen()),
            );
          }
          // Add navigation for other labels if needed
        },
        borderRadius: BorderRadius.circular(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: const Color(0xFFB39DDB)),
            const SizedBox(height: 12),
            Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  String _formatAppointmentDate(DateTime date) {
    return DateFormat('EEEE, MMMM d \'at\' h:mm a').format(date);
  }
}